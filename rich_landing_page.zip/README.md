# $RICH Landing Page

This is a simple landing page for the $RICH meme coin ecosystem. To deploy:

1. Upload files to a GitHub repo
2. Go to Settings > Pages
3. Set Source to "main" and folder to "/root"
4. Your site will be live at `https://yourusername.github.io/repo-name`

Replace placeholder images in the `images/` folder.
